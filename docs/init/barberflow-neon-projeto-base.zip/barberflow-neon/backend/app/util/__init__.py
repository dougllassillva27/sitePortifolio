"""Utilitários da aplicação."""
