"""Integrações externas."""
