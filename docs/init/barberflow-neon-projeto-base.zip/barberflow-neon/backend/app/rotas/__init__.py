"""Rotas da API BarberFlow."""
