"""Aplicação BarberFlow Neon."""
